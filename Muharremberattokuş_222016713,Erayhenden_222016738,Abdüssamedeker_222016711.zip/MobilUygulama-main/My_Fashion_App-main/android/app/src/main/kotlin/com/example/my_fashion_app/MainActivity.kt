package com.example.my_fashion_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
